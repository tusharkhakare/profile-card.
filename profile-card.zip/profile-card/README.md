# Profile Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/sanketbodke/pen/NWgKyZW](https://codepen.io/sanketbodke/pen/NWgKyZW).

In this pen I create a simple CSS Glassmorphism Card Hover Effect.